(function(){if (Notes.find().count() === 0) {
  Notes.insert({
    title: 'Introducing Telescope',
    text: 'asdf'
  });
  Notes.insert({
    title: 'Introducing Steven',
    text: 'asdasdfasdff'
  });
  Notes.insert({
    title: 'Introducing LOL',
    text: 'as213123df'
  });
}

})();
