(function(){Meteor.publish('notes', function() {
  return Notes.find();
});

})();
